# games/hangman.py
import random

# === Часть Насти (функции) ===
def load_words_from_file(filename="data/words.txt"):
    """загружает список слов из файла"""
    words_list = [] #создаем пустой файл из списка
    try: #пытаемся открыть файл для чтения
        with open(filename, 'r', encoding='utf-8') as file:
            lines = file.readlines()
            for line in lines: #обрабатываем каждую строку
                word = line.strip() #убираем пробелы и символы
                if word: #проверяем что строка не пустая
                    words_list.append(word)
    except FileNotFoundError: #если файл не найден используем стандартный набор
        print("Ошибка: Файл не найден. Используем стандартные слова.")
        words_list = ["программирование", "виселица", "студент", "алгоритм"]
    except Exception as error: #любая другая ошибка
        print(f"Произошла ошибка при чтении файла: {error}")
        words_list = ["ошибка", "исключение"]
    return words_list #возвращаем список слов

def select_random_word(words):
    """Выбирает случайное слово из списка""" #проверяем что список не пустой
    if len(words) == 0:
        return "питон"
    return random.choice(words) #слово по умолчанию

def check_letter_in_word(letter, secret_word):
    """Проверяет, есть ли буква в слове"""
    return letter in secret_word

def update_display_word(secret_word, guessed_letters):
    """Обновляет отображение слова с угаданными буквами"""
    result = ""
    for char in secret_word: #для каждой буквы в слове
        if char in guessed_letters:
            result += char + " " #если буква угадана показываем
        else:
            result += "_ " #иначе показать подчеркивание
    return result.strip()

def is_word_guessed(secret_word, guessed_letters):
    """Проверяет, полностью ли угадано слово"""
    for char in secret_word: #проверяем каждую букву в слове
        if char not in guessed_letters: #если хотя бы одна не угадана
            return False
    return True

# === Часть Тины (игровой процесс) ===
def draw_hangman_stage(incorrect_guesses):
    #рисуем виселицу как она выглядит в зависимости от количества ошибок


    #словарь с состояниями виселицы
    hangman_pictures = {
        0: """
  ------
  |    |
       |
       |
       |
       |
       |
=========""",
        1: """
  ------
  |    |
  O    |
       |
       |
       |
       |
=========""",
        2: """
  ------
  |    |
  O    |
  |    |
       |
       |
       |
=========""",
        3: """
  ------
  |    |
  O    |
 /|    |
       |
       |
       |
=========""",
        4: """
  ------
  |    |
  O    |
 /|\   |
       |
       |
       |
=========""",
        5: """
  ------
  |    |
  O    |
 /|\   |
 /     |
       |
       |
=========""",
        6: """
  ------
  |    |
  O    |
 /|\   |
 / \   |
       |
       |
========="""
    }
    #получаем картинку по количеству ошибок
    #используем метод get чтобы при ошибке игра не упала
    return hangman_pictures.get(incorrect_guesses, "Ошибка отрисовки")

def get_player_input(used_letters):
    #делаем функцию, которая получает ввод от пользователя с проверками
    while True:  #делаем бесконечный цикл пока не получим правильный ввод
        try:
            #запрашиваем ввод
            user_input = input("Введите одну букву: ").strip().lower()
            #проверяем пустой ввод
            if not user_input:
                print("Вы ничего не ввели! Попробуйте снова.")
                continue
              #проверяем одна ли буква
            if len(user_input) != 1:
                print("Пожалуйста, введите ТОЛЬКО ОДНУ букву!")
                continue
                #проверяем это буква?
            if not user_input.isalpha():
                print("Это не буква! Введите букву от 'а' до 'я'.")
                continue
             #проверяем уже вводили эту букву?   
            if user_input in used_letters:
                print(f"Вы уже вводили букву '{user_input}'! Попробуйте другую.")
                continue
                #если все проверки пройдены
            return user_input
            
        except KeyboardInterrupt:  #если пользователь нажал Ctrl+C
            print("\nИгра прервана.")
            return None
        except Exception as e:  #любая другая ошибка
            print(f"Произошла ошибка: {e}")
            continue

def play_hangman():
    #основная функция игры (объединяем все части)
    print("=" * 60)
    print("         ИГРА 'ВИСЕЛИЦА'")
    print("=" * 60)
    print("Разработчики: Настя и Тина")
    print("Дисциплина: Основы программирования на Python")
    print("=" * 60)
    
    #загружаем слова (используем функцию из части насти)
    print("\nЗагружаем слова из файла...")
    words = load_words_from_file()
    
    if len(words) == 0:
        print("Не удалось загрузить слова. Используем стандартный набор.")
        words = ["программирование", "студент", "виселица"]

    #выбор случайного слова
    secret_word = select_random_word(words)

    #инициализация игровых переменных
    guessed_letters = []   #угаданные буквы
    wrong_letters = []    #неверные буквы
    attempts_left = 6     #ск всего попыток
    game_over = False     #окончание игры
    
    print(f"\nЯ загадал слово из {len(secret_word)} букв.")
    print("У вас есть 6 попыток, чтобы угадать слово.")
    print("Давайте начинать!")
    
    #основной игровой цикл
    while not game_over and attempts_left > 0:
        print("\n" + "-" * 40)
        print(draw_hangman_stage(len(wrong_letters)))
        
        #рисуем виселицу показываем текущее состояние слова
        current_display = update_display_word(secret_word, guessed_letters)
        print(f"\nСлово: {current_display}")
        
        #показываем неверные буквы, если они есть
        if wrong_letters:
            print(f"Неверные буквы: {', '.join(wrong_letters)}")
        print(f"Осталось попыток: {attempts_left}")
        
        #получаем ввод от пользователя
        letter = get_player_input(guessed_letters + wrong_letters)
        
        #если пользователь прервал игру
        if letter is None:
            print("Игра завершена досрочно.")
            return
        
        #проверяем букву
        if check_letter_in_word(letter, secret_word):
            print(f"\n✓ Отлично! Буква '{letter}' есть в слове!")
            guessed_letters.append(letter)
        else:
            print(f"\n✗ К сожалению, буквы '{letter}' нет в слове.")
            wrong_letters.append(letter)
            attempts_left -= 1

        #проверяем выиграл ли игрок
        if is_word_guessed(secret_word, guessed_letters):
            print("\n" + "=" * 50)
            print("ПОЗДРАВЛЯЮ! ВЫ ВЫИГРАЛИ! 🎉")
            print(f"Загаданное слово: {secret_word.upper()}")
            print("=" * 50)
            game_over = True
            
    #если закончились попытки
    if attempts_left == 0 and not game_over:
        print("\n" + "=" * 50)
        print(draw_hangman_stage(6))
        print("К СОЖАЛЕНИЮ, ВЫ ПРОИГРАЛИ! 😢")
        print(f"Загаданное слово было: {secret_word.upper()}")
        print("=" * 50)
    
    #предлагаем сыграть еще раз
    print("\n" + "-" * 40)
    while True:
        choice = input("Хотите сыграть еще раз в Виселицу? (да/нет): ").lower()
        if choice in ['да', 'д', 'yes', 'y']:
            print("\n" * 3)
            play_hangman()
            break
        elif choice in ['нет', 'н', 'no', 'n']:
            print("\nВозвращаюсь в главное меню...")
            break
        else:
            print("Пожалуйста, введите 'да' или 'нет'")

#запускаееем
if __name__ == "__main__":
    play_hangman()